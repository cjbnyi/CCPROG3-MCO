package Hotel;

/** 
 * Class to contain debug variables.
*/
public final class Debug {

    public static boolean CLEAR_CONSOLE = true;
}